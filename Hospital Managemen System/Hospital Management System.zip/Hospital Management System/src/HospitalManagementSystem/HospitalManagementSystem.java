package HospitalManagementSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class HospitalManagementSystem
{
    private static final String URL = "jdbc:mysql://localhost:3306/hospital";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    public static void main(String[] args)
    {
        try
        {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Create connection
            Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            Scanner scanner = new Scanner(System.in);

            Patients patients = new Patients(connection, scanner);
            Doctor doctor = new Doctor(connection);

            while (true)
            {
                System.out.println("\n===== HOSPITAL MANAGEMENT SYSTEM =====");
                System.out.println("1 : Add Patient");
                System.out.println("2 : View Patients");
                System.out.println("3 : View Doctors");
                System.out.println("4 : Book Appointment");
                System.out.println("5 : Exit");
                System.out.print("Enter your choice : ");

                int choice = scanner.nextInt();

                switch (choice)
                {
                    case 1:
                        patients.addPatients();
                        break;

                    case 2:
                        patients.viewPatient();
                        break;

                    case 3:
                        doctor.viewDoctors();
                        break;

                    case 4:
                        bookAppointment(connection, scanner, patients, doctor);
                        break;

                    case 5:
                        System.out.println("Thank you for using the system!");
                        connection.close();
                        scanner.close();
                        return;

                    default:
                        System.out.println("Enter valid choice!");
                }
            }
        }
        catch (ClassNotFoundException | SQLException e)
        {
            e.printStackTrace();
        }
    }

    // ================= Book Appointment =================
    public static void bookAppointment(Connection connection,
                                       Scanner scanner,
                                       Patients patients,
                                       Doctor doctor)
    {
        try
        {
            System.out.print("Enter Patient ID : ");
            int patientId = scanner.nextInt();

            System.out.print("Enter Doctor ID : ");
            int doctorId = scanner.nextInt();

            System.out.print("Enter Appointment Date (YYYY-MM-DD) : ");
            String appointmentDate = scanner.next();

            if (patients.getPatientById(patientId) && doctor.getDoctorById(doctorId))
            {
                if (checkDoctorAvailability(doctorId, appointmentDate, connection))
                {
                    String query =
                            "INSERT INTO appointments(patient_id, doctor_id, appointment_date) VALUES (?,?,?)";

                    PreparedStatement ps = connection.prepareStatement(query);
                    ps.setInt(1, patientId);
                    ps.setInt(2, doctorId);
                    ps.setString(3, appointmentDate);

                    int rows = ps.executeUpdate();
                    if (rows > 0)
                    {
                        System.out.println("Appointment Booked Successfully!");
                    }
                    else
                    {
                        System.out.println("Failed to Book Appointment!");
                    }
                }
                else
                {
                    System.out.println("Doctor is not available on this date!");
                }
            }
            else
            {
                System.out.println("Either Patient or Doctor does not exist!");
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    // ================= Check Doctor Availability =================
    public static boolean checkDoctorAvailability(int doctorId,
                                                  String appointmentDate,
                                                  Connection connection)
    {
        String query =
                "SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND appointment_date = ?";

        try
        {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, doctorId);
            ps.setString(2, appointmentDate);

            ResultSet rs = ps.executeQuery();
            if (rs.next())
            {
                return rs.getInt(1) == 0;
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return false;
    }
}
